
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Zap, Globe, CreditCard, BarChart, Headphones } from "lucide-react";

const Features = () => {
  const features = [
    {
      icon: Shield,
      title: "Bank-Level Security",
      description: "PCI DSS Level 1 compliant with advanced fraud detection and data encryption to protect every transaction."
    },
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Process payments in milliseconds with 99.9% uptime guarantee and real-time transaction processing."
    },
    {
      icon: Globe,
      title: "Global Coverage",
      description: "Accept payments in 190+ countries with support for 135+ currencies and local payment methods."
    },
    {
      icon: CreditCard,
      title: "Multiple Payment Options",
      description: "Credit cards, digital wallets, bank transfers, and buy-now-pay-later options all in one platform."
    },
    {
      icon: BarChart,
      title: "Powerful Analytics",
      description: "Real-time dashboards and detailed reporting to track performance and optimize your payment flow."
    },
    {
      icon: Headphones,
      title: "24/7 Support",
      description: "Expert support team available around the clock to help you with integration and troubleshooting."
    }
  ];

  return (
    <div id="features" className="bg-gray-50 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Everything you need to accept payments
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From startups to enterprises, our comprehensive payment platform scales with your business needs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="bg-white hover:shadow-lg transition-shadow duration-300 border-0 shadow-sm">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center mb-4">
                  <feature.icon className="h-6 w-6 text-white" />
                </div>
                <CardTitle className="text-xl font-semibold text-gray-900">
                  {feature.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600 text-base leading-relaxed">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Features;
