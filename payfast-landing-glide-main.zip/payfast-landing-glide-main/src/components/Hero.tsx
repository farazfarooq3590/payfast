
import { HeroSection } from "@/components/ui/hero-section-dark";

const Hero = () => {
  return (
    <HeroSection
      title="Now processing $1B+ in payments monthly"
      subtitle={{
        regular: "Accept payments ",
        gradient: "anywhere, anytime",
      }}
      description="The complete payment solution for businesses of all sizes. Start accepting payments in minutes with our secure, scalable, and developer-friendly platform."
      ctaText="Start Free Trial"
      ctaHref="#"
      bottomImage={{
        light: "/lovable-uploads/191612d5-48fc-4792-8cb8-6e647060e33f.png",
        dark: "/lovable-uploads/191612d5-48fc-4792-8cb8-6e647060e33f.png",
      }}
      gridOptions={{
        angle: 65,
        opacity: 0.3,
        cellSize: 50,
        lightLineColor: "#e2e8f0",
        darkLineColor: "#334155",
      }}
    />
  );
};

export default Hero;
