
const TrustedBy = () => {
  const companies = [
    { name: "Shopify", logo: "S" },
    { name: "Airbnb", logo: "A" },
    { name: "Uber", logo: "U" },
    { name: "Netflix", logo: "N" },
    { name: "Spotify", logo: "S" },
    { name: "Tesla", logo: "T" },
  ];

  return (
    <div className="bg-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <p className="text-gray-600 text-lg">Trusted by 50,000+ businesses worldwide</p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 items-center">
          {companies.map((company, index) => (
            <div key={index} className="flex justify-center items-center">
              <div className="flex items-center space-x-3 opacity-60 hover:opacity-100 transition-opacity">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold">
                  {company.logo}
                </div>
                <span className="text-gray-700 font-semibold text-lg">{company.name}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TrustedBy;
